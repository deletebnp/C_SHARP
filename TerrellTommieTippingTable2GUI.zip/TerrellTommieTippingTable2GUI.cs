﻿/* Tommie Terrell
 * 2/18/2016
 * Tipping Table
 * */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TerrellTommie1TippingTable2GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


 double dinnerPrice;  /// declaring variables
 double MAXDINNER;
 double MAXRATE;
double LOWRATE;
const double TIPSTEP = 0.05; /// increase tip by .05 
const double DINNERSTEP = 10.00; /// increases dinner price by 10.00  

dinnerPrice = Convert.ToDouble(lowestDinnerTxt.Text);  /// User Input from textboxes. String being coverted to double
MAXDINNER = Convert.ToDouble(highestDinnerTxt.Text);
LOWRATE = Convert.ToDouble(lowestTipTxt.Text);
MAXRATE = Convert.ToDouble(highestTipTxt.Text);

label1.Text = (" Price");
     for (double tipRate = LOWRATE; tipRate <= MAXRATE; tipRate += TIPSTEP) /// makes the y axis
  {
    label1.Text += "      " + tipRate.ToString("F");
  }
 label1.Text += "\n";
               for (int tipRate = 0; tipRate <= 70; tipRate++)///makes line across top as 
  {
             label1.Text += "-";
}
              label1.Text += "\n";
              for (double tipRate = dinnerPrice; tipRate <= MAXDINNER; tipRate += DINNERSTEP) /// makes the x axis
{
                  label1.Text += tipRate.ToString("C");

           for (double alt = LOWRATE; alt <= MAXRATE; alt += TIPSTEP) /// fills in the table
{
                 label1.Text += "      " + (tipRate * alt).ToString("F");
}

            label1.Text += "\n";
}


        }

                   private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
