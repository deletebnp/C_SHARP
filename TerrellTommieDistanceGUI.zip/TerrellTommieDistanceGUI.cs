﻿/*
 *Tommie Terrell
 *2-3-16
 *SDEV 240
 *Program converts miles into feet
  */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double num1;
              const double num2 = 5280;
            double total;
            num1 = Convert.ToDouble(textBox1.Text);
            
            total = (num1 * num2);
            
            label2.Text = Convert.ToString(total);
        }
    }
}
